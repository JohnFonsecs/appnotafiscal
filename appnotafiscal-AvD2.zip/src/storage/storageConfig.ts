const SPENDING_COLLECTION = '@appfiscal:spending'

const CLIENTS_COLLECTION = '@appfiscal:clients'

export { SPENDING_COLLECTION, CLIENTS_COLLECTION }